class DemoWebPOMController {

    static BUTTON_EJ_1 = "body > main > section:nth-of-type(2) > p:nth-of-type(2) > input:first-of-type";

    static BUTTON_EJ_2 = "body > main > section:nth-of-type(3) > p:nth-of-type(2) > input:first-of-type";

    static NUMBER_1_EJ_3 = "body > main > section:nth-of-type(4) > form:first-of-type > p:nth-of-type(1) > input";
    static NUMBER_2_EJ_3 = "body > main > section:nth-of-type(4) > form:first-of-type > p:nth-of-type(2) > input";
    static BUTTON_EJ_3 = "body > main > section:nth-of-type(4) > form:first-of-type > p:nth-of-type(3) > input";

    static NUMBER_1_EJ_4 = "body > main > section:nth-of-type(5) > form:first-of-type > p:nth-of-type(1) > input";
    static NUMBER_2_EJ_4 = "body > main > section:nth-of-type(5) > form:first-of-type > p:nth-of-type(2) > input";
    static BUTTON_EJ_4 = "body > main > section:nth-of-type(5) > form:first-of-type > p:nth-of-type(3) > input";

    static NUMBER_EJ_5 = "body > main > section:nth-of-type(6) > form:first-of-type > p:nth-of-type(1) > input";
    static CHAR_EJ_5 = "body > main > section:nth-of-type(6) > form:first-of-type > p:nth-of-type(2) > input";
    static BUTTON_EJ_5 = "body > main > section:nth-of-type(6) > form:first-of-type > p:nth-of-type(3) > input";

    static NUMBER_EJ_6 = "body > main > section:nth-of-type(7) > form:first-of-type > p:nth-of-type(1) > input";
    static BUTTON_EJ_6 = "body > main > section:nth-of-type(7) > form:first-of-type > p:nth-of-type(2) > input";

    static NUMBER_EJ_7 = "body > main > section:nth-of-type(8) > form:first-of-type > p:nth-of-type(1) > input";
    static BUTTON_EJ_7_1 = "body > main > section:nth-of-type(8) > form:first-of-type > p:nth-of-type(2) > input";
    static TEXT_EJ_7 = "body > main > section:nth-of-type(8) > form:nth-of-type(2) > p:nth-of-type(1) > input";
    static BUTTON_EJ_7_2 = "body > main > section:nth-of-type(8) > form:nth-of-type(2) > p:nth-of-type(2) > input";

    static LAST_P_EJ_8 = "body > main > section:nth-of-type(9) > p:first-of-type";
    static BUTTON_EJ_8 = "body > main > section:nth-of-type(9) > p:nth-of-type(2) > input";

    static REGION_EJ_9 = "body > main > section:nth-of-type(10) > form:first-of-type > fieldset:first-of-type > select:first-of-type";
    static BIRTH_DATE_EJ_9 = "body > main > section:nth-of-type(10) > form:first-of-type > fieldset:first-of-type > p:nth-of-type(3) > input";
    static INTERESTS_EJ_9 = "body > main > section:nth-of-type(10) > form:first-of-type > fieldset:first-of-type > select:nth-of-type(2)";
    static BUTTON_EJ_9 = "body > main > section:nth-of-type(10) > form:first-of-type > fieldset:first-of-type > p:last-of-type > input";

    static NAME_EJ_10 = "body > main > section:nth-of-type(11) > form:first-of-type > fieldset:first-of-type > p:nth-of-type(2) > input";
    static PRICE_EJ_10 = "body > main > section:nth-of-type(11) > form:first-of-type > fieldset:nth-of-type(2) > p:first-of-type > input";
    static FEE_EJ_10 = "body > main > section:nth-of-type(11) > form > fieldset:nth-child(2) > p:nth-child(3) > select";
    static PROMOTION_EJ_10 = "body > main > section:nth-of-type(11) > form:first-of-type > fieldset:nth-of-type(2) > p:last-of-type > input";
    static PROMOTION_LABEL_EJ_10 = "body > main > section:nth-of-type(11) > form:first-of-type > fieldset:nth-of-type(2) > p:last-of-type > label";
    static BUTTON_EJ_10 = "body > main > section:nth-of-type(11) > form:first-of-type >  p:last-of-type > input";

    constructor() {
        this.ejercicio1 = new Ejercicio1();
        this.ejercicio2 = new Ejercicio2();
        this.ejercicio3 = new Ejercicio3();
        this.ejercicio4 = new Ejercicio4();
        this.ejercicio5 = new Ejercicio5();
        this.ejercicio6 = new Ejercicio6();
        this.ejercicio7_1 = new Ejercicio7_1();
        this.ejercicio7_2 = new Ejercicio7_2();
        this.ejercicio8 = new Ejercicio8();
        this.ejercicio9 = new Ejercicio9();
        this.ejercicio10 = new Ejercicio10();

        window.addEventListener("DOMContentLoaded", (function (event) {

            /* EJERCICIO 1 */
            document.querySelector(DemoWebPOMController.BUTTON_EJ_1).addEventListener("click", this.ejercicio1.execute.bind(this.ejercicio1));
        
            /* EJERCICIO 2 */
            document.querySelector(DemoWebPOMController.BUTTON_EJ_2).addEventListener("click", this.ejercicio2.execute.bind(this.ejercicio2));
        
            /* EJERCICIO 3 */
            document.querySelector(DemoWebPOMController.BUTTON_EJ_3).addEventListener("click", this.ejercicio3.execute.bind(this.ejercicio3));
        
            /* EJERCICIO 4 */
            document.querySelector(DemoWebPOMController.BUTTON_EJ_4).addEventListener("click", this.ejercicio4.execute.bind(this.ejercicio4));
        
            /* EJERCICIO 5 */
            document.querySelector(DemoWebPOMController.BUTTON_EJ_5).addEventListener("click", this.ejercicio5.execute.bind(this.ejercicio5));

            /* EJERCICIO 6 */
            document.querySelector(DemoWebPOMController.BUTTON_EJ_6).addEventListener("click", this.ejercicio6.execute.bind(this.ejercicio6));

            /* EJERCICIO 7 */
            document.querySelector(DemoWebPOMController.BUTTON_EJ_7_1).addEventListener("click", this.ejercicio7_1.execute.bind(this.ejercicio7_1));
            document.querySelector(DemoWebPOMController.BUTTON_EJ_7_2).addEventListener("click", this.ejercicio7_2.execute.bind(this.ejercicio7_2));

            /* EJERCICIO 8 */
            document.querySelector(DemoWebPOMController.BUTTON_EJ_8).addEventListener("click", this.ejercicio8.execute.bind(this.ejercicio8));

            /* EJERCICIO 9 */
            document.querySelector(DemoWebPOMController.BUTTON_EJ_9).addEventListener("click", this.ejercicio9.execute.bind(this.ejercicio9));

            /* EJERCICIO 10 */
            document.querySelector(DemoWebPOMController.BUTTON_EJ_10).addEventListener("click", this.ejercicio10.execute.bind(this.ejercicio10));
        
        }).bind(this));
    }

}

let init = new DemoWebPOMController();