class Ejercicio5 {
    constructor() {}

    execute() {
        let numberDNI = new Number(0);
        try {
            numberDNI = new Number(document.querySelector(DemoWebPOMController.NUMBER_EJ_5).value);
        } catch (error) {
            alert("Error al obtener el número de DNI");
            return;
        }
        if (numberDNI < 0 || numberDNI > 99999999) {
            alert("El número de DNI debe estar comprendido entre 0 y 99999999");
            return;
        }

        let charDNI = new String("");
        try {
            charDNI = (new String(document.querySelector(DemoWebPOMController.CHAR_EJ_5).value));
        } catch (error) {
            alert("Error al obtener el carácter del DNI");
            return;
        }
        if (charDNI === null || typeof(charDNI) === 'undefined' || charDNI.length !== 1) {
            alert("El carácter del DNI debe ser un único caracter");
            return;
        }
        let safeCharDNI = charDNI.toUpperCase().charAt(0);
        if (!safeCharDNI.match(/[A-Z]/i)) {
            alert("El carácter del DNI debe estar comprendido entre A y Z");
            return;
        }

        let strategy = new DNIValidatorStrategy(numberDNI, safeCharDNI);

        let message = (new String("El DNI ")).concat(new String(numberDNI)).concat(new String(charDNI));
        if (strategy.validateDNI())
            message = message.concat(" es correcto.");
        else
            message = message.concat(" es incorrecto.\nCon ese número, se esperaba el siguiente DNI: ").concat(new String(numberDNI)).concat(new String(strategy.getExpectedChar())).concat(".");

        alert(message);
    }
}