class Ejercicio9 {
    constructor() {}

    execute() {
        let region = new String("");
        try {
            region = new String(document.querySelector(DemoWebPOMController.REGION_EJ_9).value);
        } catch (error) {
            alert("Error al obtener la provincia");
            return;
        }
        if (region.length === 0) {
            alert("La provincia está vacía.");
            return;
        }

        let birthDate = new String("");
        try {
            birthDate = new String(document.querySelector(DemoWebPOMController.BIRTH_DATE_EJ_9).value);
        } catch (error) {
            alert("Error al obtener la fecha de nacimiento");
            return;
        }
        if (birthDate.length === 0) {
            alert("La fecha de nacimiento está vacía.");
            return;
        }

        let interests = new String("");
        let interestsIndex = -1;
        try {
            let interestsDOMElement = document.querySelector(DemoWebPOMController.INTERESTS_EJ_9);
            interestsIndex = new Number(interestsDOMElement.selectedIndex);
            if (interestsDOMElement.selectedIndex !== -1)
                interests = new String(interestsDOMElement.options[interestsDOMElement.selectedIndex].text);
        } catch (error) {
            alert("Error al obtener los intereses");
            return;
        }
        if (interestsIndex === -1) {
            alert("No se ha seleccionado ningún interés.");
            return;
        }

        alert((new String("Provincia: ")).concat(region).concat("\nFecha de nacimiento: ").concat(birthDate).concat("\nTema de interés: ").concat(interests));
    }

}