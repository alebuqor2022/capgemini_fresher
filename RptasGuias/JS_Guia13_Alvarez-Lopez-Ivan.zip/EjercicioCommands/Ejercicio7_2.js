class Ejercicio7_2 {
    constructor() {}

    execute() {
        let text = new String("");
        try {
            text = new String(document.querySelector(DemoWebPOMController.TEXT_EJ_7).value);
        } catch (error) {
            alert("Error al obtener el número");
            return;
        }
        text = text.replace(/[^A-Za-z]/g, "");
        
        let message = (new String("La cadena de texto \"")).concat(text).concat("\" está compuesta de ");
        if (text.length === 0)
            message = message.concat("ningún caracter.");
        else if (text.match(/^[A-Z]+$/)) 
            message = message.concat("sólo letras mayúsculas.");
        else if (text.match(/^[a-z]+$/)) 
            message = message.concat("sólo letras minúsculas.");
        else
            message = message.concat("una mezcla de letras mayúsculas y minúsculas.");

        alert(message);
    }

}