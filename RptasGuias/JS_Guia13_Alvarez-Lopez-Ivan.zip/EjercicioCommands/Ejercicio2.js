class Ejercicio2 {
    constructor() {}

    execute() {
        let meses = ["Enero", "Febrero", "Marzo", "Abril", "Mayo", "Junio", "Julio", "Agosto", "Septiembre", "Octubre", "Noviembre", "Diciembre"];
        alert(meses.join("\n"));
    }
}