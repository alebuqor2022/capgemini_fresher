class Ejercicio3 {
    constructor() {}

    execute() {
        let number1 = new Number(0);
        try {
            number1 = new Number(document.querySelector(DemoWebPOMController.NUMBER_1_EJ_3).value);
        } catch (error) {
            alert("Error al obtener el primer número");
            return;
        }

        let number2 = 0;
        try {
            number2 = new Number(document.querySelector(DemoWebPOMController.NUMBER_2_EJ_3).value);
        } catch (error) {
            alert("Error al obtener el segundo número");
            return;
        }

        alert((new NumberComparatorStrategy(number1, number2)).execute());
    }
}