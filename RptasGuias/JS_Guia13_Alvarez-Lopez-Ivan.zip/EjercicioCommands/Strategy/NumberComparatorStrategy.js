class NumberComparatorStrategy {
    constructor(number1, number2) {
        this.number1 = number1;
        this.number2 = number2;
    }

    execute() {
        let mensaje = new String("El primer número (").concat(this.number1).concat(") es ");
        if (this.number1 > this.number2)
            mensaje = mensaje.concat("mayor");
        else if (this.number1 < this.number2)
            mensaje = mensaje.concat("menor");
        else
            mensaje = mensaje.concat("igual");
        return mensaje.concat(" que el segundo número (").concat(this.number2).concat(").");
    }
}