class DNIValidatorStrategy {

    static DNI_LETTERS = ['T', 'R', 'W', 'A', 'G', 'M', 'Y', 'F', 'P', 'D', 'X', 'B', 'N' , 'J', 'Z', 'S', 'Q', 'V', 'H', 'L', 'C', 'K', 'E', 'T'];

    constructor(number, char) {
        this.number = number;
        this.char = char;
        this.expectedChar = null;
        this.validity = null;
    }

    validateDNI() {
        if (this.validity === null) {
            this.expectedChar = DNIValidatorStrategy.DNI_LETTERS[Math.trunc(this.number % 23)];
            this.validity = (this.char == this.expectedChar);
        }
        return this.validity;
    }

    getExpectedChar() {
        if (this.expectedChar === null)
            this.validateDNI();
        return this.expectedChar;
    }
}