class Ejercicio1 {
    constructor() {}

    execute() {
        let mensaje = "<javascript>\n\nHola Mundo!\nQué fácil es incluir 'comillas simples' y \"comillas dobles\"";
        alert(mensaje);
    }
}