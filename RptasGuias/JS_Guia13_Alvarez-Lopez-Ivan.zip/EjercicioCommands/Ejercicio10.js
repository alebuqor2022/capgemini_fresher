class Ejercicio10 {
    constructor() {}

    execute() {
        let validations = [];
        let productName = new String("");
        try {
            productName = new String(document.querySelector(DemoWebPOMController.NAME_EJ_10).value);
        } catch (error) {
            alert("Error al obtener el nombre del producto");
            return;
        }
        if (productName.length === 0)
            validations.push("El nombre del producto está vacío.");

        let price = new Number(0);
        try {
            price = new Number(document.querySelector(DemoWebPOMController.PRICE_EJ_10).value);
        } catch (error) {
            alert("Error al obtener el precio del producto");
            return;
        }
        if (price <= 120)
            validations.push("El precio del producto debe ser mayor a 120$.");

        let fee = new String("");
        let feeIndex = -1;
        try {
            let feeDOMElement = document.querySelector(DemoWebPOMController.FEE_EJ_10);
            feeIndex = new Number(feeDOMElement.selectedIndex);
            if (feeDOMElement.selectedIndex !== -1)
                fee = new String(feeDOMElement.options[feeDOMElement.selectedIndex].text);
        } catch (error) {
            alert("Error al obtener el impuesto");
            return;
        }
        if (feeIndex === -1) {
            alert("No se ha seleccionado ningún impuesto.");
            return;
        }
        if (fee == "4%" || fee == "7%")
            validations.push((new String("Estás tomando un impuesto bajo: ")).concat(fee));

        let promotion = false;
        let promotionText = new String("");
        try {
            promotion = document.querySelector(DemoWebPOMController.PROMOTION_EJ_10).checked;
            promotionText = new String(document.querySelector(DemoWebPOMController.PROMOTION_LABEL_EJ_10).textContent);
        } catch (error) {
            alert("Error al obtener el precio del producto");
            return;
        }
        if (promotion)
            validations.push((new String("La opción ")).concat(promotionText).concat(" es la más acertada."));
        
        if (validations.length !== 0) {
            let message = (new String("Fallos de validación:\n"));
            for (let iVal in validations)
                message = message.concat("- ").concat(validations[iVal]).concat("\n");

            alert(message);
            return;
        }

        alert("Todo válido");
    }

}