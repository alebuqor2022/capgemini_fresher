class Ejercicio4 {
    constructor() {}

    execute() {
        let number1 = new Number(0);
        try {
            number1 = new Number(document.querySelector(DemoWebPOMController.NUMBER_1_EJ_4).value);
        } catch (error) {
            alert("Error al obtener el primer número");
            return;
        }

        let number2 = 0;
        try {
            number2 = new Number(document.querySelector(DemoWebPOMController.NUMBER_2_EJ_4).value);
        } catch (error) {
            alert("Error al obtener el segundo número");
            return;
        }

        alert((new String((new NumberComparatorStrategy(number1, number2)).execute()))
                .concat("\nDespués de aumentar una unidad al primer número, el resultado sería el siguiente.\n")
                .concat((new NumberComparatorStrategy(number1 + 1, number2)).execute()));
    }
}