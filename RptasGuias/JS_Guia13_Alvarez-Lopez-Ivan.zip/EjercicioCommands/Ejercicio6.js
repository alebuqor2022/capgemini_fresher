class Ejercicio6 {
    constructor() {}

    execute() {
        let number = new Number(0);
        try {
            number = new Number(document.querySelector(DemoWebPOMController.NUMBER_EJ_6).value);
        } catch (error) {
            alert("Error al obtener el número");
            return;
        }
        if (number < 0) {
            alert("Sólo se puede calcular el factorial de números naturales positivos");
            return;
        }
        
        let result = 1;
        for (let i = 1; i <= number; i++)
            result = result * i;

        alert((new String("El factorial de ")).concat(new String(number)).concat(" es ").concat(new String(result)).concat("."));
    }
}