class Ejercicio7_1 {
    constructor() {}

    execute() {
        let number = new Number(0);
        try {
            number = new Number(document.querySelector(DemoWebPOMController.NUMBER_EJ_7).value);
        } catch (error) {
            alert("Error al obtener el número");
            return;
        }
        
        let message = (new String("El número ")).concat(number).concat(" es ");
        if (!this.isEven(number))
            message = message.concat("im");
        message = message.concat("par.");

        alert(message);
    }

    isEven(number) {
        return ((number % 2) == 0);
    }
}