class Ejercicio8 {
    constructor() {
        this.wasExecuted = false;
    }

    execute() {
        if (this.wasExecuted)
            return;

        let messages = [];
        messages.push((new String("Número de enlaces de la página: ")).concat(new String(document.links.length)));
        messages.push((new String("Dirección a la que enlaza el último enlace: ")).concat(new String(document.links[document.links.length - 1].href)));
        messages.push((new String("Cantidad de párrafos: ")).concat(document.getElementsByTagName("p").length));
        
        for (let iMes = messages.length - 1; iMes >= 0; iMes--) {
            let lastP = document.querySelector(DemoWebPOMController.LAST_P_EJ_8);
            let newP = document.createElement("p");
            newP.textContent = new String(messages[iMes]);
            lastP.parentNode.insertBefore(newP, lastP.nextSibling);
        }

        this.wasExecuted = true;
    }
}