
/**
 * Ejercitación 5
 */
window.onload=function(){
    const button5=document.querySelector('#ej5');

    button5.addEventListener('click',function(){

        const letras = ['T', 'R', 'W', 'A', 'G', 'M', 'Y', 'F', 'P', 'D', 'X', 'B','N', 'J', 'Z', 'S', 'Q', 'V', 'H', 'L', 'C', 'K', 'E', 'T'];
        const dni=document.getElementById("input1");
        const textodni=dni.value;
        const regexdni=/^\d{8}[a-zA-Z]$/;
        const letra=textodni.charAt(textodni.length-1).toUpperCase();
        const numeros=parseInt(textodni.substring(0,textodni.length-1));
    
        if(regexdni.test(textodni)){
            window.alert("El DNI es valido.");
            const letracalculada=letras[numeros % 23];
                if(letracalculada==letra){
                    window.alert("Numero y letra de DNI correctos")
                }
                else{
                    window.alert("Letra de DNI no corresponde con el número");
                }
    
        }else{
            window.alert("El DNI no es válido");
        }
    
    });

}