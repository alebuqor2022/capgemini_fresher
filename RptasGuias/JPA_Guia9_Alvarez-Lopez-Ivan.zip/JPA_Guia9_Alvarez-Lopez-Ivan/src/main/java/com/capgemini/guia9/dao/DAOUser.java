package com.capgemini.guia9.dao;

import java.util.List;

import com.capgemini.guia9.CommandExecutor;
import com.capgemini.guia9.dao.user.CreateUser;
import com.capgemini.guia9.dao.user.DeleteUser;
import com.capgemini.guia9.dao.user.ReadAllUser;
import com.capgemini.guia9.dao.user.ReadOneUser;
import com.capgemini.guia9.dao.user.UpdateUser;
import com.capgemini.guia9.model.User;

public class DAOUser {

	private static CommandExecutor executor = new CommandExecutor();

	public static void create(User p) {
		executor.execute(new CreateUser(p));
	}

	public static User readOne(Long id) {
		return executor.execute(new ReadOneUser(id));
	}

	public static List<User> readAll() {
		return executor.execute(new ReadAllUser());
	}

	public static void update(User p) {
		executor.execute(new UpdateUser(p));
	}

	public static void delete(User p) {
		executor.execute(new DeleteUser(p));
	}

}
