package com.capgemini.guia9;

import jakarta.persistence.EntityManager;

public interface Command<T> {
	T execute();

	void setEntityManager(EntityManager em);
}