package com.capgemini.guia9.dao.bankingTransaction;

import com.capgemini.guia9.Command;
import com.capgemini.guia9.model.CashTransaction;

import jakarta.persistence.EntityManager;

public class CreateCashTransaction implements Command<CashTransaction> {

	private EntityManager entityManager;

	private CashTransaction entry;

	public CreateCashTransaction(CashTransaction entry) {
		super();
		this.entry = entry;
	}

	@Override
	public CashTransaction execute() {
		if (this.entry == null)
			throw new IllegalArgumentException("El objeto es null");
		entityManager.persist(entry);
		return entry;
	}

	@Override
	public void setEntityManager(EntityManager em) {
		this.entityManager = em;
	}

}
