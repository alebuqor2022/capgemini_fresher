package com.capgemini.guia9.dao.employee;

import com.capgemini.guia9.Command;
import com.capgemini.guia9.model.Employee;

import jakarta.persistence.EntityManager;

public class DeleteEmployee implements Command<Employee> {

	private EntityManager entityManager;
	private Employee entry;

	public DeleteEmployee(Employee entry) {
		super();
		this.entry = entry;
	}

	public Employee execute() {
		if (this.entry == null)
			throw new IllegalArgumentException("El objeto es null");

		entry = entityManager.find(Employee.class, entry.getId());
		if (entry != null) {
			entityManager.merge(entry);
			entityManager.remove(entry);
		}

		return entry;
	}

	public void setEntityManager(EntityManager em) {
		this.entityManager = em;
	}

}
