package com.capgemini.guia9.dao.bankingTransaction;

import java.util.List;

import com.capgemini.guia9.Command;
import com.capgemini.guia9.model.StockTransaction;

import jakarta.persistence.EntityManager;
import jakarta.persistence.TypedQuery;

public class ReadAllStockTransaction implements Command<List<StockTransaction>> {

	private EntityManager entityManager;

	public ReadAllStockTransaction() {
		super();
	}

	@Override
	public List<StockTransaction> execute() {
		String queryString = "SELECT e FROM StockTransaction e";
		TypedQuery<StockTransaction> query = entityManager.createQuery(queryString, StockTransaction.class);
		return query.getResultList();
	}

	@Override
	public void setEntityManager(EntityManager em) {
		this.entityManager = em;
	}

}
