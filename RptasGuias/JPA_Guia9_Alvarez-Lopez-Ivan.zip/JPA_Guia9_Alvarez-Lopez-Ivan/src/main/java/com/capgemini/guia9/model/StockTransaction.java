package com.capgemini.guia9.model;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;

@Entity
public class StockTransaction extends BankingTransaction {

	private static final long serialVersionUID = -6279040995763563675L;

	@Column(name = "sale")
	private boolean isSale;

	@Column(name = "stock_symbol")
	private String stockSymbol;

	@Column(name = "company_name")
	private String companyName;

	@Column(name = "num_shares")
	private Integer numShares;

	@Column(name = "price_per_share")
	private Double pricePerShare;

	public boolean isSale() {
		return isSale;
	}

	public void setSale(boolean isSale) {
		this.isSale = isSale;
	}

	public String getStockSymbol() {
		return stockSymbol;
	}

	public void setStockSymbol(String stockSymbol) {
		this.stockSymbol = stockSymbol;
	}

	public String getCompanyName() {
		return companyName;
	}

	public void setCompanyName(String companyName) {
		this.companyName = companyName;
	}

	public Integer getNumShares() {
		return numShares;
	}

	public void setNumShares(Integer numShares) {
		this.numShares = numShares;
	}

	public Double getPricePerShare() {
		return pricePerShare;
	}

	public void setPricePerShare(Double pricePerShare) {
		this.pricePerShare = pricePerShare;
	}

	@Override
	public String toString() {
		return "StockTransaction [isSale=" + isSale + ", stockSymbol=" + stockSymbol + ", companyName=" + companyName
				+ ", numShares=" + numShares + ", pricePerShare=" + pricePerShare + ", getId()=" + getId()
				+ ", getTxType()=" + getTxType() + ", getTxDate()=" + getTxDate() + ", getTxDescription()="
				+ getTxDescription() + ", getTxFee()=" + getTxFee() + "]";
	}

}
