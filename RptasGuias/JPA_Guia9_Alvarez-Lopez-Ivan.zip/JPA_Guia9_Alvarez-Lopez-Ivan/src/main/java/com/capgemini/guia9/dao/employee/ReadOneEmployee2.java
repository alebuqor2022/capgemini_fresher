package com.capgemini.guia9.dao.employee;

import com.capgemini.guia9.Command;
import com.capgemini.guia9.model.Employee;

import jakarta.persistence.EntityManager;
import jakarta.persistence.TypedQuery;

public class ReadOneEmployee2 implements Command<Employee> {

	private EntityManager entityManager;
	private long id;

	public ReadOneEmployee2(long id) {
		super();
		this.id = id;
	}

	public Employee execute() {
		TypedQuery<Employee> query = entityManager.createQuery("SELECT e FROM Employee e WHERE e.id = ?1",
				Employee.class);
		query.setParameter(1, id);
		return query.getSingleResult();
	}

	public void setEntityManager(EntityManager em) {
		this.entityManager = em;
	}

}
