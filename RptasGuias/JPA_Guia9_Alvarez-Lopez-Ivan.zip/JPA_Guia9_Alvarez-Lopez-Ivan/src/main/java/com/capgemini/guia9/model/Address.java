package com.capgemini.guia9.model;

import java.io.Serializable;

import jakarta.persistence.Basic;
import jakarta.persistence.Embeddable;

@Embeddable
public class Address implements Serializable {

	private static final long serialVersionUID = 1768021899307827257L;

	@Basic
	private String calle;

	@Basic
	private int numero;

	@Basic
	private String codigoPostal;

	@Basic
	private String ciudad;

	public String getCalle() {
		return calle;
	}

	public void setCalle(String calle) {
		this.calle = calle;
	}

	public int getNumero() {
		return numero;
	}

	public void setNumero(int numero) {
		this.numero = numero;
	}

	public String getCodigoPostal() {
		return codigoPostal;
	}

	public void setCodigoPostal(String codigoPostal) {
		this.codigoPostal = codigoPostal;
	}

	public String getCiudad() {
		return ciudad;
	}

	public void setCiudad(String ciudad) {
		this.ciudad = ciudad;
	}

	@Override
	public String toString() {
		return "Address [calle=" + calle + ", numero=" + numero + ", codigoPostal=" + codigoPostal + ", ciudad="
				+ ciudad + "]";
	}

}
