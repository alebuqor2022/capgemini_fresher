package com.capgemini.guia9.model;

import java.io.Serializable;
import java.sql.Date;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Inheritance;
import jakarta.persistence.InheritanceType;

/*
 * Mapped Superclass. Existe una tabla por cada clase hija.
 * Los atributos de la clase padre aparecen como columnas en las tablas de las clases hijas.
 * Usando esta estrategia, la clase padre no podrá contener asociaciones.
 * 
 * -> En la clase padre:
 * @MappedSuperclass // Sin @Entity
 * 
 * -> En las clases hijas:
 * @Entity
 */

/*
 * Table Per Class. Existe una tabla para cada clase de la jerarquía.
 * Los atributos de la clase padre aparecen como columnas en las tablas de las clases hijas.
 * También existe una tabla para la clase padre.
 * Usando esta estrategia, no podemos autogenerar IDs.
 * 
 * -> En la clase padre:
 * @Entity
 * @Inheritance(strategy = InheritanceType.JOINED)
 * 
 * -> En las clases hijas:
 * @Entity
 * @PrimaryKeyJoinColumn(name = "...")
 */

/*
 * Single Table. Existe una tabla para toda la jerarquía.
 * Una única tabla aglutina todos los campos de todas las clases hijas.
 * 
 * -> En la clase padre:
 * @Entity
 * @Inheritance(strategy = InheritanceType.SINGLE_TABLE)
 * @DiscriminatorColumn(name = "...")
 * 
 * -> En las clases hijas:
 * @Entity
 * @DiscriminatorValue("1")
 */

/*
 * Joined Table. Existe una tabla cada clase la jerarquía.
 * Cada clase tiene su propia tabla, incluyendo a la clase padre.
 * 
 * -> En la clase padre:
 * @Entity
 * @Inheritance(strategy = InheritanceType.JOINED)
 * 
 * -> En las clases hijas:
 * @Entity
 * @PrimaryKeyJoinColumn(name = "...")
 */

@Entity
@Inheritance(strategy = InheritanceType.JOINED)
public abstract class BankingTransaction implements Serializable {

	private static final long serialVersionUID = 1443378906965622403L;

	@Id
	@Column
	@GeneratedValue(strategy = GenerationType.AUTO)
	private Long id;

	@Column(name = "transaction_type")
	private String txType;

	@Column(name = "transaction_date")
	private Date txDate;

	@Column(name = "transaction_description")
	private String txDescription;

	@Column(name = "transaction_fee")
	private Double txFee;

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getTxType() {
		return txType;
	}

	public void setTxType(String txType) {
		this.txType = txType;
	}

	public Date getTxDate() {
		return txDate;
	}

	public void setTxDate(Date txDate) {
		this.txDate = txDate;
	}

	public String getTxDescription() {
		return txDescription;
	}

	public void setTxDescription(String txDescription) {
		this.txDescription = txDescription;
	}

	public Double getTxFee() {
		return txFee;
	}

	public void setTxFee(Double txFee) {
		this.txFee = txFee;
	}

	@Override
	public abstract String toString();

}
