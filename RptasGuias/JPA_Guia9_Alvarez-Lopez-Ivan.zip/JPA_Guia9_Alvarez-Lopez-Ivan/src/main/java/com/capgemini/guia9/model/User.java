package com.capgemini.guia9.model;

import java.io.Serializable;

import jakarta.persistence.AttributeOverride;
import jakarta.persistence.AttributeOverrides;
import jakarta.persistence.Column;
import jakarta.persistence.Embedded;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;

@Entity
@Table(name = "Users")
public class User implements Serializable {

	private static final long serialVersionUID = -80836031209303777L;

	@Id
	@Column(name = "user_id")
	@GeneratedValue(strategy = GenerationType.AUTO)
	private Long id;

	@Column(name = "first_name")
	private String name;

	@Column(name = "last_name")
	private String surname;

	@Column(name = "username")
	private String username;

	@Column(name = "password")
	private String password;

	@Column(name = "email")
	private String email;

	@Column(name = "ranking")
	private int ranking;

	@Column(name = "admin")
	private boolean isAdmin;

	@AttributeOverrides({ @AttributeOverride(name = "calle", column = @Column(name = "domicilio_particular_calle")),
			@AttributeOverride(name = "numero", column = @Column(name = "domicilio_particular_numero")),
			@AttributeOverride(name = "codigoPostal", column = @Column(name = "domicilio_particular_codigo_postal")),
			@AttributeOverride(name = "ciudad", column = @Column(name = "domicilio_particular_ciudad")) })
	@Embedded
	private Address domicilioParticular;

	@AttributeOverrides({ @AttributeOverride(name = "calle", column = @Column(name = "domicilio_de_trabajo_calle")),
			@AttributeOverride(name = "numero", column = @Column(name = "domicilio_de_trabajo_numero")),
			@AttributeOverride(name = "codigoPostal", column = @Column(name = "domicilio_de_trabajo_codigo_postal")),
			@AttributeOverride(name = "ciudad", column = @Column(name = "domicilio_de_trabajo_ciudad")) })
	@Embedded
	private Address domicilioDeTrabajo;

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getSurname() {
		return surname;
	}

	public void setSurname(String surname) {
		this.surname = surname;
	}

	public String getUsername() {
		return username;
	}

	public void setUsername(String username) {
		this.username = username;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public int getRanking() {
		return ranking;
	}

	public void setRanking(int ranking) {
		this.ranking = ranking;
	}

	public boolean isAdmin() {
		return isAdmin;
	}

	public void setAdmin(boolean isAdmin) {
		this.isAdmin = isAdmin;
	}

	public Address getDomicilioParticular() {
		return domicilioParticular;
	}

	public void setDomicilioParticular(Address domicilioParticular) {
		this.domicilioParticular = domicilioParticular;
	}

	public Address getDomicilioDeTrabajo() {
		return domicilioDeTrabajo;
	}

	public void setDomicilioDeTrabajo(Address domicilioDeTrabajo) {
		this.domicilioDeTrabajo = domicilioDeTrabajo;
	}

	@Override
	public String toString() {
		return "User [id=" + id + ", name=" + name + ", surname=" + surname + ", username=" + username + ", password="
				+ password + ", email=" + email + ", ranking=" + ranking + ", isAdmin=" + isAdmin
				+ ", domicilioParticular=" + domicilioParticular + ", domicilioDeTrabajo=" + domicilioDeTrabajo + "]";
	}

}
