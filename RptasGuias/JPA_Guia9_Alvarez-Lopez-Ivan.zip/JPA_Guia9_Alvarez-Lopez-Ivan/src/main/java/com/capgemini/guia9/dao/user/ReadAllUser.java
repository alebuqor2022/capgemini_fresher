package com.capgemini.guia9.dao.user;

import java.util.List;

import com.capgemini.guia9.Command;
import com.capgemini.guia9.model.User;

import jakarta.persistence.EntityManager;
import jakarta.persistence.TypedQuery;

public class ReadAllUser implements Command<List<User>> {

	private EntityManager entityManager;

	public ReadAllUser() {
		super();
	}

	@Override
	public List<User> execute() {
		String queryString = "SELECT e FROM User e";
		TypedQuery<User> query = entityManager.createQuery(queryString, User.class);
		return query.getResultList();
	}

	@Override
	public void setEntityManager(EntityManager em) {
		this.entityManager = em;
	}

}
