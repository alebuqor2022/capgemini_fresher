package com.capgemini.guia9.dao.employee;

import com.capgemini.guia9.Command;
import com.capgemini.guia9.model.Employee;

import jakarta.persistence.EntityManager;

public class UpdateEmployee implements Command<Employee> {

	private EntityManager entityManager;
	private Employee entry;

	public UpdateEmployee(Employee entry) {
		super();
		this.entry = entry;
	}

	public Employee execute() {
		if (this.entry == null)
			throw new IllegalArgumentException("El objeto Employee es null");

		entityManager.merge(entry);

		return entry;
	}

	public void setEntityManager(EntityManager em) {
		this.entityManager = em;
	}

}
