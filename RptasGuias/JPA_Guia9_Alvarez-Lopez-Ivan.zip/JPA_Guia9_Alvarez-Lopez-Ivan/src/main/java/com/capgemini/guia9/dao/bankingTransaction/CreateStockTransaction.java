package com.capgemini.guia9.dao.bankingTransaction;

import com.capgemini.guia9.Command;
import com.capgemini.guia9.model.StockTransaction;

import jakarta.persistence.EntityManager;

public class CreateStockTransaction implements Command<StockTransaction> {

	private EntityManager entityManager;

	private StockTransaction entry;

	public CreateStockTransaction(StockTransaction entry) {
		super();
		this.entry = entry;
	}

	@Override
	public StockTransaction execute() {
		if (this.entry == null)
			throw new IllegalArgumentException("El objeto es null");
		entityManager.persist(entry);
		return entry;
	}

	@Override
	public void setEntityManager(EntityManager em) {
		this.entityManager = em;
	}

}
