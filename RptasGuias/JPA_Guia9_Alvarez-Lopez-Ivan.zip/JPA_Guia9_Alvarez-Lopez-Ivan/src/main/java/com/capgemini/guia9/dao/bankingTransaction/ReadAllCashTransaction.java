package com.capgemini.guia9.dao.bankingTransaction;

import java.util.List;

import com.capgemini.guia9.Command;
import com.capgemini.guia9.model.CashTransaction;

import jakarta.persistence.EntityManager;
import jakarta.persistence.TypedQuery;

public class ReadAllCashTransaction implements Command<List<CashTransaction>> {

	private EntityManager entityManager;

	public ReadAllCashTransaction() {
		super();
	}

	@Override
	public List<CashTransaction> execute() {
		String queryString = "SELECT e FROM CashTransaction e";
		TypedQuery<CashTransaction> query = entityManager.createQuery(queryString, CashTransaction.class);
		return query.getResultList();
	}

	@Override
	public void setEntityManager(EntityManager em) {
		this.entityManager = em;
	}

}
