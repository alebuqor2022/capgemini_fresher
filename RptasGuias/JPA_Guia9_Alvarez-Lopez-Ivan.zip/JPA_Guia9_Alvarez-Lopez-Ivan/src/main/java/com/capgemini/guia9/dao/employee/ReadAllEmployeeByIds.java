package com.capgemini.guia9.dao.employee;

import java.util.List;

import com.capgemini.guia9.Command;
import com.capgemini.guia9.model.Employee;

import jakarta.persistence.EntityManager;
import jakarta.persistence.TypedQuery;

public class ReadAllEmployeeByIds implements Command<List<Employee>> {

	private EntityManager entityManager;

	private List<Long> ids;

	public ReadAllEmployeeByIds(List<Long> ids) {
		super();
		this.ids = ids;
	}

	@Override
	public List<Employee> execute() {
		String queryString = "SELECT e FROM Employee e WHERE e.id IN (?1)";
		TypedQuery<Employee> query = entityManager.createQuery(queryString, Employee.class);
		query.setParameter(1, ids);
		return query.getResultList();
	}

	@Override
	public void setEntityManager(EntityManager em) {
		this.entityManager = em;
	}

}
