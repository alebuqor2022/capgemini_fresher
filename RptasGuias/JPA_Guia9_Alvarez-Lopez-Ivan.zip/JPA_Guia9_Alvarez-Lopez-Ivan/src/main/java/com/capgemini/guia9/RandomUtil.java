package com.capgemini.guia9;

import java.sql.Date;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;
import java.util.Random;
import java.util.UUID;

import com.capgemini.guia9.model.Address;
import com.capgemini.guia9.model.CashTransaction;
import com.capgemini.guia9.model.Employee;
import com.capgemini.guia9.model.StockTransaction;
import com.capgemini.guia9.model.User;

public class RandomUtil {

	public static List<CashTransaction> randomCashTransactions(int quantity) {
		List<CashTransaction> transactions = new ArrayList<>();
		for (int i = 0; i < quantity; i++)
			transactions.add(randomCashTransaction());
		return transactions;
	}

	public static CashTransaction randomCashTransaction() {
		Random random = new Random();
		CashTransaction transaction = new CashTransaction();
		transaction.setTxType("TX_TYPE");
		transaction.setTxDate(Date.valueOf(LocalDate.now()));
		transaction.setTxDescription("TX_DESCRIPTION");
		transaction.setTxFee(random.nextDouble(10));

		transaction.setDeposit(random.nextBoolean());
		transaction.setMoneyAmount(random.nextDouble(100) + 0.01);
		return transaction;
	}

	public static List<StockTransaction> randomStockTransactions(int quantity) {
		List<StockTransaction> transactions = new ArrayList<>();
		for (int i = 0; i < quantity; i++)
			transactions.add(randomStockTransaction());
		return transactions;
	}

	public static StockTransaction randomStockTransaction() {
		Random random = new Random();
		StockTransaction transaction = new StockTransaction();
		transaction.setTxType("TX_TYPE");
		transaction.setTxDate(Date.valueOf(LocalDate.now()));
		transaction.setTxDescription("TX_DESCRIPTION");
		transaction.setTxFee(random.nextDouble(10));

		transaction.setSale(random.nextBoolean());
		String stockSymbol = "";
		for (int i = 0; i < 3; i++)
			stockSymbol += ((char) (random.nextInt(26) + ((int) 'a')));
		transaction.setStockSymbol(stockSymbol);
		transaction.setCompanyName("Capgemini");
		transaction.setNumShares(random.nextInt(100) + 1);
		transaction.setPricePerShare(random.nextDouble(100) + 0.01);
		return transaction;
	}

	public static List<User> randomUsers(int quantity) {
		List<User> users = new ArrayList<>();
		for (int i = 0; i < quantity; i++)
			users.add(randomUser());
		return users;
	}

	public static User randomUser() {
		Random random = new Random();
		User user = new User();
		user.setName(NAMES[random.nextInt(NAMES.length)]);
		user.setSurname(SURNAMES[random.nextInt(SURNAMES.length)]);

		String email = user.getName();
		for (int i = 0; i < 5; i++)
			email += random.nextInt(10);
		user.setUsername(email);
		email += "@email.com";
		user.setEmail(email);

		user.setPassword(UUID.randomUUID().toString());
		user.setRanking(random.nextInt(10) + 1);
		user.setAdmin(random.nextInt(2) == 1);

		Address domicilioParticular = new Address();
		domicilioParticular.setCalle("C/ Domicilio particular");
		domicilioParticular.setNumero(5);
		domicilioParticular.setCodigoPostal("33001");
		domicilioParticular.setCiudad("Oviedo");
		user.setDomicilioParticular(domicilioParticular);

		Address domicilioDeTrabajo = new Address();
		domicilioDeTrabajo.setCalle("C/ Domicilio de trabajo");
		domicilioDeTrabajo.setNumero(3);
		domicilioDeTrabajo.setCodigoPostal("33991");
		domicilioDeTrabajo.setCiudad("Gijón");
		user.setDomicilioDeTrabajo(domicilioDeTrabajo);

		return user;
	}

	public static List<Employee> randomEmployees(int quantity) {
		List<Employee> employees = new ArrayList<>();
		for (int i = 0; i < quantity; i++)
			employees.add(randomEmployee());
		return employees;
	}

	public static Employee randomEmployee() {
		Random random = new Random();
		Employee employee = new Employee();
		employee.setName(NAMES[random.nextInt(NAMES.length)]);
		employee.setSurname(SURNAMES[random.nextInt(SURNAMES.length)]);

		String email = employee.getName();
		for (int i = 0; i < 5; i++)
			email += random.nextInt(10);
		email += "@email.com";
		employee.setEmail(email);

		String phone = "+34 ";
		for (int i = 0; i < 3; i++) {
			for (int j = 0; j < 3; j++)
				phone += "" + random.nextInt(10);
			phone += " ";
		}
		employee.setPhone(phone);

		employee.setHireDate(Date.valueOf(LocalDate.now().minusMonths(2 + random.nextInt(10))));
		employee.setSalary(1000 + random.nextInt(5000));
		employee.setComission((random.nextInt(2) == 1) ? (random.nextInt(100) + 1) : 0);
		employee.setBonus((random.nextInt(2) == 1) ? "" + (1000 + random.nextInt(5000)) : "" + 0);

		return employee;
	}

	public static final String[] NAMES = new String[] { //
			"Pablo", "Juan", "Enrique", "María", "Marcos", "Pedro", "Mateo", "Ricardo" };
	public static final String[] SURNAMES = new String[] { //
			"Álvarez", "Pérez", "Rodríguez", "López", "Fernández", "Gutiérrez", "Márquez", "Alonso" };

}
