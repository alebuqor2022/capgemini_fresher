package com.capgemini.guia9.dao.user;

import com.capgemini.guia9.Command;
import com.capgemini.guia9.model.User;

import jakarta.persistence.EntityManager;

public class ReadOneUser implements Command<User> {

	private EntityManager entityManager;
	private long id;

	public ReadOneUser(long id) {
		super();
		this.id = id;
	}

	public User execute() {
		User persona = entityManager.find(User.class, id);
		if (persona != null)
			entityManager.merge(persona);
		return persona;
	}

	public void setEntityManager(EntityManager em) {
		this.entityManager = em;
	}

}
