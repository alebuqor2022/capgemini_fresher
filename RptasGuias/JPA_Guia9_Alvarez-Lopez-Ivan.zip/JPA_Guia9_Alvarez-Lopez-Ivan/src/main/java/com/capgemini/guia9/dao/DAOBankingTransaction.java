package com.capgemini.guia9.dao;

import java.util.List;

import com.capgemini.guia9.CommandExecutor;
import com.capgemini.guia9.dao.bankingTransaction.CreateCashTransaction;
import com.capgemini.guia9.dao.bankingTransaction.CreateStockTransaction;
import com.capgemini.guia9.dao.bankingTransaction.ReadAllCashTransaction;
import com.capgemini.guia9.dao.bankingTransaction.ReadAllStockTransaction;
import com.capgemini.guia9.model.CashTransaction;
import com.capgemini.guia9.model.StockTransaction;

public class DAOBankingTransaction {

	private static CommandExecutor executor = new CommandExecutor();

	public static void create(CashTransaction p) {
		executor.execute(new CreateCashTransaction(p));
	}

	public static void create(StockTransaction p) {
		executor.execute(new CreateStockTransaction(p));
	}

	public static List<CashTransaction> readAllCashTransaction() {
		return executor.execute(new ReadAllCashTransaction());
	}

	public static List<StockTransaction> readAllStockTransaction() {
		return executor.execute(new ReadAllStockTransaction());
	}

}
