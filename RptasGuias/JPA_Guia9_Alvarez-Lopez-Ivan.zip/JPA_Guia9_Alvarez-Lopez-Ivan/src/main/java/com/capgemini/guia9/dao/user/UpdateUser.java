package com.capgemini.guia9.dao.user;

import com.capgemini.guia9.Command;
import com.capgemini.guia9.model.User;

import jakarta.persistence.EntityManager;

public class UpdateUser implements Command<User> {

	private EntityManager entityManager;
	private User entry;

	public UpdateUser(User entry) {
		super();
		this.entry = entry;
	}

	public User execute() {
		if (this.entry == null)
			throw new IllegalArgumentException("El objeto User es null");

		entityManager.merge(entry);

		return entry;
	}

	public void setEntityManager(EntityManager em) {
		this.entityManager = em;
	}

}
