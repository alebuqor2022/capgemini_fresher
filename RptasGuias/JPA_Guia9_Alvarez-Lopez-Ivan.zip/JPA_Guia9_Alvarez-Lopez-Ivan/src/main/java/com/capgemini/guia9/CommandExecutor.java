package com.capgemini.guia9;

import jakarta.persistence.EntityManager;
import jakarta.persistence.EntityTransaction;

public class CommandExecutor {
	public <T> T execute(Command<T> cmd) {
		T result = null;
		EntityManager em = EntityManagerFactorySingleton.getEmf().createEntityManager();
		EntityTransaction tx = em.getTransaction();
		tx.begin();
		try {
			cmd.setEntityManager(em);
			result = cmd.execute();
			tx.commit();
		} catch (Exception e) {
			tx.rollback();
			e.printStackTrace();
		} finally {
			em.close();
		}
		return result;
	}

}