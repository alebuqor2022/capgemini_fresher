package com.capgemini.guia9;

import jakarta.persistence.EntityManagerFactory;
import jakarta.persistence.Persistence;

public class EntityManagerFactorySingleton {

	private static final EntityManagerFactory entityManagerFactorySingleton;

	// Reemplazo el metodo constructor de instancias, uso el inicializador estatico
	static {
		try {
			entityManagerFactorySingleton = Persistence.createEntityManagerFactory("JPA_Demo");
		} catch (Throwable ex) {
			System.err.println("Error al inicializar la factoría EntityManager");
			throw new ExceptionInInitializerError(ex);
		}
	}

	public static EntityManagerFactory getEmf() {
		return entityManagerFactorySingleton;
	}

}
