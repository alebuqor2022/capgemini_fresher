package com.capgemini.guia9.model;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;

@Entity
public class CashTransaction extends BankingTransaction {

	private static final long serialVersionUID = 2708648575751229389L;

	@Column(name = "deposit")
	private boolean isDeposit;

	@Column(name = "money_amounts")
	private Double moneyAmount;

	public boolean isDeposit() {
		return isDeposit;
	}

	public void setDeposit(boolean isDeposit) {
		this.isDeposit = isDeposit;
	}

	public Double getMoneyAmount() {
		return moneyAmount;
	}

	public void setMoneyAmount(Double moneyAmount) {
		this.moneyAmount = moneyAmount;
	}

	@Override
	public String toString() {
		return "CashTransaction [isDeposit=" + isDeposit + ", moneyAmount=" + moneyAmount + ", getId()=" + getId()
				+ ", getTxType()=" + getTxType() + ", getTxDate()=" + getTxDate() + ", getTxDescription()="
				+ getTxDescription() + ", getTxFee()=" + getTxFee() + "]";
	}

}
