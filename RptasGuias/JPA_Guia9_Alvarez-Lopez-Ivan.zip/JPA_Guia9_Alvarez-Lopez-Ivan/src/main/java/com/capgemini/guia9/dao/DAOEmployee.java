package com.capgemini.guia9.dao;

import java.util.List;

import com.capgemini.guia9.CommandExecutor;
import com.capgemini.guia9.dao.employee.CreateEmployee;
import com.capgemini.guia9.dao.employee.DeleteEmployee;
import com.capgemini.guia9.dao.employee.ReadAllEmployee;
import com.capgemini.guia9.dao.employee.ReadAllEmployeeByIds;
import com.capgemini.guia9.dao.employee.ReadOneEmployee1;
import com.capgemini.guia9.dao.employee.UpdateEmployee;
import com.capgemini.guia9.model.Employee;

public class DAOEmployee {

	private static CommandExecutor executor = new CommandExecutor();

	public static void create(Employee p) {
		executor.execute(new CreateEmployee(p));
	}

	public static Employee readOne(Long id) {
		return executor.execute(
//
//				new ReadOneEmployee(id)
				new ReadOneEmployee1(id)
//				new ReadOneEmployee2(id)
//				
		);
	}

	public static List<Employee> readAll() {
		return executor.execute(new ReadAllEmployee());
	}

	public static List<Employee> readAllByIds(List<Long> ids) {
		return executor.execute(new ReadAllEmployeeByIds(ids));
	}

	public static void update(Employee p) {
		executor.execute(new UpdateEmployee(p));
	}

	public static void delete(Employee p) {
		executor.execute(new DeleteEmployee(p));
	}

}
