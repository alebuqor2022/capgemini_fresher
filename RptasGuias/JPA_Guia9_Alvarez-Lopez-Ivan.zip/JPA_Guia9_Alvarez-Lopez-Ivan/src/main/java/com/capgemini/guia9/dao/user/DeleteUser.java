package com.capgemini.guia9.dao.user;

import com.capgemini.guia9.Command;
import com.capgemini.guia9.model.User;

import jakarta.persistence.EntityManager;

public class DeleteUser implements Command<User> {

	private EntityManager entityManager;
	private User entry;

	public DeleteUser(User entry) {
		super();
		this.entry = entry;
	}

	public User execute() {
		if (this.entry == null)
			throw new IllegalArgumentException("El objeto es null");

		entry = entityManager.find(User.class, entry.getId());
		if (entry != null) {
			entityManager.merge(entry);
			entityManager.remove(entry);
		}

		return entry;
	}

	public void setEntityManager(EntityManager em) {
		this.entityManager = em;
	}

}
