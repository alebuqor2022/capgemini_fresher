package com.capgemini.guia9;

import java.util.ArrayList;
import java.util.List;

import com.capgemini.guia9.dao.DAOBankingTransaction;
import com.capgemini.guia9.dao.DAOEmployee;
import com.capgemini.guia9.dao.DAOUser;
import com.capgemini.guia9.model.CashTransaction;
import com.capgemini.guia9.model.Employee;
import com.capgemini.guia9.model.StockTransaction;
import com.capgemini.guia9.model.User;

public class Main {

	public static final int QUANTITY_OF_EMPLOYEES = 5;
	public static final int QUANTITY_OF_USERS = 5;
	public static final int QUANTITY_OF_CASH_TRANSACTIONS = 10;
	public static final int QUANTITY_OF_STOCK_TRANSACTIONS = 10;

	public static void main(String[] args) {
		crearYListarEmpleados();
		crearYListarUsuarios();
		crearYListarTransaccionesDeDinero();
		crearYListarTransaccionesDeStock();
		consultaEnEmployeeConParametros();
	}

	public static void consultaEnEmployeeConParametros() {
		List<Employee> employees = new ArrayList<>();
		for (int i = 0; i < QUANTITY_OF_EMPLOYEES; i++)
			employees.add(DAOEmployee.readOne((long) (i + 1)));
		System.out.println("-> BUSCAR EMPLEADO POR ID <-");
		for (Employee employee : employees)
			System.out.println("- Empleado con ID " + employee.getId() + ": " + employee);
		System.out.println();

		List<Long> ids = new ArrayList<>();
		for (int i = 0; i < QUANTITY_OF_EMPLOYEES; i++)
			ids.add((long) (i + 1));
		List<Employee> foundEmployees = DAOEmployee.readAllByIds(ids);
		System.out.println("-> BUSCAR EMPLEADOS POR LISTA DE IDS <-");
		for (Employee employee : foundEmployees)
			System.out.println("- Empleado con ID " + employee.getId() + ": " + employee);
		System.out.println();
	}

	public static void crearYListarTransaccionesDeStock() {
		List<StockTransaction> stockTransactions = RandomUtil.randomStockTransactions(QUANTITY_OF_STOCK_TRANSACTIONS);
		for (StockTransaction stockTransaction : stockTransactions)
			DAOBankingTransaction.create(stockTransaction);
		System.out.println("-> SE VAN A CREAR LAS SIGUIENTES TRANSACCIONES DE STOCK <-");
		for (StockTransaction stockTransaction : stockTransactions)
			System.out.println("Transacción creada: " + stockTransaction);
		System.out.println();

		List<StockTransaction> foundStockTransactions = DAOBankingTransaction.readAllStockTransaction();
		System.out.println("-> LISTADO DE TODAS LAS TRANSACCIONES DE STOCK <-");
		for (StockTransaction stockTransaction : foundStockTransactions)
			System.out.println("Transacción encontrada: " + stockTransaction);
		System.out.println();
	}

	public static void crearYListarTransaccionesDeDinero() {
		List<CashTransaction> cashTransactions = RandomUtil.randomCashTransactions(QUANTITY_OF_CASH_TRANSACTIONS);
		for (CashTransaction cashTransaction : cashTransactions)
			DAOBankingTransaction.create(cashTransaction);
		System.out.println("-> SE VAN A CREAR LAS SIGUIENTES TRANSACCIONES DE DINERO <-");
		for (CashTransaction cashTransaction : cashTransactions)
			System.out.println("Transacción creada: " + cashTransaction);
		System.out.println();

		List<CashTransaction> foundCashTransactions = DAOBankingTransaction.readAllCashTransaction();
		System.out.println("-> LISTADO DE TODAS LAS TRANSACCIONES DE DINERO <-");
		for (CashTransaction cashTransaction : foundCashTransactions)
			System.out.println("Transacción encontrada: " + cashTransaction);
		System.out.println();
	}

	public static void crearYListarUsuarios() {
		List<User> users = RandomUtil.randomUsers(QUANTITY_OF_USERS);
		for (User user : users)
			DAOUser.create(user);
		System.out.println("-> SE VAN A CREAR LOS SIGUIENTES USUARIOS <-");
		for (User user : users)
			System.out.println("Usuario creado: " + user);
		System.out.println();

		List<User> foundUsers = DAOUser.readAll();
		System.out.println("-> LISTADO DE TODOS LOS USUARIOS <-");
		for (User user : foundUsers)
			System.out.println("Usuario encontrado: " + user);
		System.out.println();
	}

	public static void crearYListarEmpleados() {
		List<Employee> employees = RandomUtil.randomEmployees(QUANTITY_OF_EMPLOYEES);
		for (Employee employee : employees)
			DAOEmployee.create(employee);
		System.out.println("-> SE VAN A CREAR LOS SIGUIENTES EMPLEADOS <-");
		for (Employee employee : employees)
			System.out.println("Empleado creado: " + employee);
		System.out.println();

		List<Employee> foundEmployees = DAOEmployee.readAll();
		System.out.println("-> LISTADO DE TODOS LOS EMPLEADOS <-");
		for (Employee employee : foundEmployees)
			System.out.println("Empleado encontrado: " + employee);
		System.out.println();
	}

}
