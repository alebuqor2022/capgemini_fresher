package com.capgemini.guia9.dao.employee;

import com.capgemini.guia9.Command;
import com.capgemini.guia9.model.Employee;

import jakarta.persistence.EntityManager;

public class ReadOneEmployee implements Command<Employee> {

	private EntityManager entityManager;
	private long id;

	public ReadOneEmployee(long id) {
		super();
		this.id = id;
	}

	public Employee execute() {
		Employee persona = entityManager.find(Employee.class, id);
		if (persona != null)
			entityManager.merge(persona);
		return persona;
	}

	public void setEntityManager(EntityManager em) {
		this.entityManager = em;
	}

}
