package com.capgemini.biblioteca;

import org.junit.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ProyectoBibliotecaApplicationTests {

	@Test
	void contextLoads() {
	}

}
