package com.capgemini.biblioteca.service;

import java.util.List;

import org.springframework.stereotype.Service;

import com.capgemini.biblioteca.model.Reserva;

@Service
public interface ReservasService {
	List<Reserva> getAllReservas();

	void saveReserva(Reserva reserva);

	Reserva getReservaById(long id);

	void deleteReservaById(long id);

	List<Reserva> getAllReservasByLectorId(long idLector);
	
	List<Reserva> getAllReservasByLibroId(long idLibro);
}
