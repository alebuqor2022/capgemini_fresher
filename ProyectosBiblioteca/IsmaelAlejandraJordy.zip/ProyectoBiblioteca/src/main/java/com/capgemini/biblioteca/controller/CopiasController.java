package com.capgemini.biblioteca.controller;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.capgemini.biblioteca.model.Copia;
import com.capgemini.biblioteca.model.Lector;
import com.capgemini.biblioteca.service.CopiaService;
import com.capgemini.biblioteca.service.LectorService;

@Controller
public class CopiasController {
	@Autowired
	private CopiaService cs;

	@Autowired
	private LectorService ls;

	@GetMapping("/copias/libro")
	private String viewCopiasLibro(@RequestParam(name = "idLibro", required = true) long idLibro, Model model) {
		List<Copia> copias = cs.getAllCopiasByLibroId(idLibro);
		model.addAttribute("copias", copias);
		model.addAttribute("lector", new Lector());
		return "copias";
	}

	@GetMapping("/copias/lector")
	private String viewCopiasLector(@RequestParam(name = "idLector", required = true) long idLector, Model model) {
		List<Copia> copias = cs.getAllCopias();
		Lector lector = ls.getLectorById(idLector);

		model.addAttribute("copias", copias);
		model.addAttribute("lector", lector);

		return "copias";
	}

	@GetMapping("/copias/lector/libroTitulo")
	private String viewCopiasLectorLibro(@RequestParam(name = "idLector", required = true) long idLector,
			@RequestParam(name = "tituloLibro") String tituloLibro, Model model) {
		List<Copia> copias = new ArrayList<Copia>();;
		if (tituloLibro != "") {
			copias = cs.getAllByTituloContains(tituloLibro);
		} else {
			copias = cs.getAllCopias();
		}

		Lector lector = ls.getLectorById(idLector);

		model.addAttribute("copias", copias);
		model.addAttribute("lector", lector);

		return "copias";
	}
	
	@GetMapping("/copias/lector/libro")
	private String viewCopiasLectorLibroId(@RequestParam(name = "idLector", required = true) long idLector,
			@RequestParam(name = "idLibro") long idLibro, Model model) {
		List<Copia> copias = new ArrayList<Copia>();;
		copias = cs.getAllCopiasByLibroId(idLibro);

		Lector lector = ls.getLectorById(idLector);

		model.addAttribute("copias", copias);
		model.addAttribute("lector", lector);

		return "copias";
	}
}
