package com.capgemini.biblioteca.controller;

import java.util.List;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.capgemini.biblioteca.model.Prestamo;
import com.capgemini.biblioteca.service.PrestamosService;

@Controller
public class PrestamosController {
	@Autowired
	private PrestamosService ps;

	@GetMapping("/prestamos/lector")
	private String viewPrestamosLector(@RequestParam(name = "idLector", required = true) long idLector,Model model) {
		List<Prestamo> prestamos = ps.getAllPrestamosByLectorId(idLector);
		model.addAttribute("prestamos", prestamos);

		return "prestamos";
	}
	
	@GetMapping("/prestamos")
	private String viewPrestamos(Model model) {
		List<Prestamo> prestamos = ps.getAllPrestamos();
		prestamos = prestamos.stream().sorted((o1, o2) -> o2.getId().compareTo(o1.getId())).collect(Collectors.toList());
		model.addAttribute("prestamos", prestamos);

		return "prestamos";
	}
}
