package com.capgemini.biblioteca.service;

import java.util.List;

import com.capgemini.biblioteca.model.Copia;

public interface CopiaService {
	List<Copia> getAllCopias();
	
	List<Copia> getAllCopiasByLibroId(long idLibro);
	
	List<Copia> getAllByTituloContains(String titulo);

	void saveCopia(Copia copia);

	Copia getCopiaById(long id);

	void deleteCopiaById(long id);
}
