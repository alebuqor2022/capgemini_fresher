package com.capgemini.biblioteca.model;

import java.util.Set;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.Table;

@Entity
@Table(name = "copias")
public class Copia {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long id;

	@Column
	private EstadoCopia estado;

	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "fk_libro")
	private Libro libro;
	
	@OneToMany(mappedBy = "copia", targetEntity = Prestamo.class, cascade = CascadeType.ALL)
	private Set<Prestamo> prestamos;

	public Copia() {
		
	}
	public Copia(EstadoCopia estado, Libro libro) {
		super();
		this.estado = estado;
		this.libro = libro;
	}

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public EstadoCopia getEstado() {
		return estado;
	}

	public void setEstado(EstadoCopia estado) {
		this.estado = estado;
	}

	public Libro getLibro() {
		return libro;
	}

	public void setLibro(Libro libro) {
		this.libro = libro;
	}

	
}
