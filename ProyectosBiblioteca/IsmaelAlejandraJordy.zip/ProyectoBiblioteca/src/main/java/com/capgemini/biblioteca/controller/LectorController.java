package com.capgemini.biblioteca.controller;

import java.time.LocalDate;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.capgemini.biblioteca.model.Lector;
import com.capgemini.biblioteca.model.Multa;
import com.capgemini.biblioteca.service.LectorService;
import com.capgemini.biblioteca.service.MultaService;

@Controller
public class LectorController {

	@Autowired
	private LectorService ls;

	@Autowired
	private MultaService ms;

	@GetMapping("/")
	public String viewHome(Model model) {
		List<Lector> lectores = ls.getAllLectores();
		List<Multa> multas;
		for (Lector l : lectores) {
			multas = ms.getAllMultasVigentesByIdLector(l.getnSocio());
			if (multas.size() > 0) {
				l.setMultado(true);
			}
		}
		model.addAttribute("lectores", lectores);

		return "index";
	}

	@GetMapping("/prestar")
	public String viewPrestar(@RequestParam(name = "idLector", required = true) long idLector,
			@RequestParam(name = "idCopia", required = true) long idCopia, Model model) {

		ls.prestar(idLector, idCopia, LocalDate.now());

		return "redirect:/prestamos";
	}

	@GetMapping("/devolver")
	public String viewDevolver(@RequestParam(name = "idPrestamo", required = true) long idPrestamo, Model model) {

		ls.devolver(idPrestamo, LocalDate.now());

		return "redirect:/prestamos";
	}
	

	@GetMapping("/reservar")
	public String reservar(@RequestParam(name = "idLector", required = true) long idLector,
			@RequestParam(name = "idLibro", required = true) long idLibro) {
		ls.reservar(idLector, idLibro, LocalDate.now());
		
		return "redirect:/reservas";
	}

	@GetMapping("/lectores/add")
	public String viewAddNuevoLector(Model model) {
		Lector lector = new Lector();
		model.addAttribute("lector", lector);
		return "nuevo_lector";
	}

	@PostMapping("/lectores/save")
	public String saveLector(@ModelAttribute("lector") Lector lector) {
		ls.saveLector(lector);
		return "redirect:/";
	}
}
