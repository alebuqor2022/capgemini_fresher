package com.capgemini.biblioteca.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.capgemini.biblioteca.model.Multa;
import com.capgemini.biblioteca.service.LectorService;
import com.capgemini.biblioteca.service.MultaService;

@Controller
public class MultasController {

	@Autowired
	private MultaService ms;
	
	@Autowired
	private LectorService ls;

	@GetMapping("/multas")
	public String viewMultas(Model model) {
		List<Multa> multas = ms.getAllMultas();

		model.addAttribute("multas", multas);
		
		return "multas";
	}
	
	@GetMapping("/multas/crear")
	public String viewCrearMultas(@RequestParam(name = "idLector", required = true) long idLector,
			@RequestParam(name = "dias", required = true) int dias,Model model) {
		ls.multar(idLector, dias);

		return "redirect:/multas";
	}
}
