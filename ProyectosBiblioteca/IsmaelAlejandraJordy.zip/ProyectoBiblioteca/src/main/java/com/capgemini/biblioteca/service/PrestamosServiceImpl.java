package com.capgemini.biblioteca.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.capgemini.biblioteca.model.Prestamo;
import com.capgemini.biblioteca.repository.PrestamoRepository;

@Service
public class PrestamosServiceImpl implements PrestamosService {

	@Autowired
	private PrestamoRepository prestamoRepository;
	
	@Override
	public List<Prestamo> getAllPrestamos() {
		return prestamoRepository.findAll();
	}

	@Override
	public void savePrestamo(Prestamo prestamo) {
		prestamoRepository.save(prestamo);
	}

	@Override
	public Prestamo getPrestamoById(long id) {
		Optional<Prestamo> optionalPrestamo = prestamoRepository.findById(id);
		Prestamo prestamo = null;
		if (optionalPrestamo.isPresent()) {
			prestamo = optionalPrestamo.get();
		} else {
			throw new RuntimeException("No se encontró multa " + id);
		}
		return prestamo;
	}

	@Override
	public void deletePrestamoById(long id) {
		prestamoRepository.deleteById(id);
	}

	@Override
	public List<Prestamo> getAllPrestamosByLectorId(long idLector) {
		return prestamoRepository.findAllByLector_nSocio(idLector);
	}
}
