package com.capgemini.biblioteca.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;

import com.capgemini.biblioteca.model.Autor;
import com.capgemini.biblioteca.service.AutorService;

@Controller
public class AutoresController {
	
	@Autowired
	private AutorService as;
	
	@GetMapping("/autores/add")
	public String viewAddNuevoAutor(Model model) {
		Autor autor = new Autor();
		model.addAttribute("autor", autor);
		return "nuevo_autor";
	}

	@PostMapping("/autores/save")
	public String saveAutor(@ModelAttribute("autor") Autor autor) {
		as.saveAutor(autor);
		return "redirect:/libros/add";
	}
}
