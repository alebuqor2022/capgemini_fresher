package com.capgemini.biblioteca.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.capgemini.biblioteca.model.Copia;
import com.capgemini.biblioteca.model.Libro;
import com.capgemini.biblioteca.model.Prestamo;
import com.capgemini.biblioteca.repository.CopiaRepository;
import com.capgemini.biblioteca.repository.LibroRepository;
import com.capgemini.biblioteca.repository.PrestamoRepository;
import com.capgemini.biblioteca.repository.ReservaRepository;

@Service
public class LibroServiceImpl implements LibroService {
	
	@Autowired
	private LibroRepository libroRepository;
	@Autowired
	private PrestamoRepository prestamoRepository;
	@Autowired
	private CopiaRepository copiaRepository;
	@Autowired
	private ReservaRepository reservaRepository;
	
	@Override
	public List<Libro> getAllLibros() {
		return libroRepository.findAll();
	}

	@Override
	public void saveLibro(Libro libro) {
		libroRepository.save(libro);
	}

	@Override
	public Libro getLibroById(long id) {
		Optional<Libro> optionalLibro = libroRepository.findById(id);
		Libro libro = null;
		if (optionalLibro.isPresent()) {
			libro = optionalLibro.get();
		} else {
			throw new RuntimeException("El libro numero " + id + " No se encuentra");
		}
		return libro;
	}

	@Override
	public void deleteLibroById(long id) {
//		List<Copia> copias = copiaRepository.findAllByLibroId(id);
//		for (Copia c : copias) {
//			prestamoRepository.deleteAllByCopiaId(c.getId());
////			List<Prestamo> prestamos = prestamoRepository.findAllByCopiaId(c.getId()).get();
////			for (Prestamo p : prestamos) 
//		}
//		reservaRepository.deleteAllByLibroId(id);
		libroRepository.deleteById(id);
		
	}

	@Override
	public List<Libro> getAllLibrosTitulo(String titulo) {
		return libroRepository.findByTituloContains(titulo);
	}

}
