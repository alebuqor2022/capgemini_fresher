package com.capgemini.biblioteca.service;

import java.util.List;

import com.capgemini.biblioteca.model.Multa;

public interface MultaService {
	List<Multa> getAllMultas();
	
	List<Multa> getAllMultasVigentesByIdLector(long idLector);

	void saveMulta(Multa copia);

	Multa getMultaById(long id);

	void deleteMultaById(long id);
	
	List<Multa> getAllMultaByIdLector(long idLector);
}

