package com.capgemini.biblioteca.service;

import java.util.List;

import org.springframework.stereotype.Service;

import com.capgemini.biblioteca.model.Prestamo;

@Service
public interface PrestamosService {
	List<Prestamo> getAllPrestamos();

	void savePrestamo(Prestamo prestamo);

	Prestamo getPrestamoById(long id);

	void deletePrestamoById(long id);

	List<Prestamo> getAllPrestamosByLectorId(long idLector);
}
