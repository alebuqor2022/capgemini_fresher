package com.capgemini.biblioteca.service;

import java.time.LocalDate;
import java.util.List;

import com.capgemini.biblioteca.model.Lector;

public interface LectorService {
	List<Lector> getAllLectores();

	void saveLector(Lector lector);

	Lector getLectorById(long id);

	void deleteLectorById(long id);

	void devolver(long idPrestamo, LocalDate fechaAct);

	void prestar(long idLector, long idCopia, LocalDate fechaAct);

	void multar(long idLector, int dias);
	
	void reservar(long idLector, long idLibro, LocalDate fechaAct);
}
