package com.capgemini.biblioteca.model;

public enum EstadoCopia {
	prestado, retraso, biblioteca, reparacion
}
