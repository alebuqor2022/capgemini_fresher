package com.capgemini.biblioteca.service;

import java.util.List;

import com.capgemini.biblioteca.model.Libro;

public interface LibroService {
	List<Libro> getAllLibros();
	
	List<Libro> getAllLibrosTitulo(String titulo);
	
	void saveLibro(Libro copia);

	Libro getLibroById(long id);

	void deleteLibroById(long id);
}
