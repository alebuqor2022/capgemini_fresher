package com.capgemini.biblioteca.repository;

import java.util.List;
import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;

import com.capgemini.biblioteca.model.Multa;

public interface MultaRepository extends JpaRepository<Multa, Long> {
	Optional<Multa> findByLector_nSocio(long id);
	List<Multa> findAllByLector_nSocio(long id);
}
