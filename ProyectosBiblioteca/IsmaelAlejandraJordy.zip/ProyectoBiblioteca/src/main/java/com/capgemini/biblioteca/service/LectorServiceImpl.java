package com.capgemini.biblioteca.service;

import java.time.LocalDate;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.capgemini.biblioteca.model.Copia;
import com.capgemini.biblioteca.model.EstadoCopia;
import com.capgemini.biblioteca.model.Lector;
import com.capgemini.biblioteca.model.Libro;
import com.capgemini.biblioteca.model.Multa;
import com.capgemini.biblioteca.model.Prestamo;
import com.capgemini.biblioteca.model.Reserva;
import com.capgemini.biblioteca.repository.CopiaRepository;
import com.capgemini.biblioteca.repository.LectorRepository;
import com.capgemini.biblioteca.repository.LibroRepository;
import com.capgemini.biblioteca.repository.MultaRepository;
import com.capgemini.biblioteca.repository.PrestamoRepository;
import com.capgemini.biblioteca.repository.ReservaRepository;

@Service
public class LectorServiceImpl implements LectorService {
	private static final int MAX_PRESTAMOS = 3;

	private static final long DIAS_RESERVA = 2;

	private static final String EMAIL_SUBJECT = "RESERVA DISPONIBLE";

	private static final String EMAIL_MESSAGE = "Tiene 48 horas para recoger su reserva";

	private static EmailSenderService emailUtil;

	@Autowired
	private LectorRepository lectorRepository;

	@Autowired
	private MultaRepository multaRepository;

	@Autowired
	private PrestamoRepository prestamoRepository;

	@Autowired
	private CopiaRepository copiaRepository;

	@Autowired
	private LibroRepository libroRepository;

	@Autowired
	private ReservaRepository reservaRepository;

	@Autowired
	private EmailSenderService sender;

	
	@Override
	public List<Lector> getAllLectores() {
		return lectorRepository.findAll();
	}

	@Override
	public void saveLector(Lector lector) {
		lectorRepository.save(lector);
	}

	@Override
	public Lector getLectorById(long id) {
		Optional<Lector> optionalLector = lectorRepository.findById(id);
		Lector lector = null;
		if (optionalLector.isPresent()) {
			lector = optionalLector.get();
		} else {
			throw new RuntimeException("El lector no se encuentra nro " + id);
		}
		return lector;
	}

	@Override
	public void deleteLectorById(long id) {
		lectorRepository.deleteById(id);
	}

	@Override
	public void devolver(long idPrestamo, LocalDate fechaAct) {
		if (prestamoRepository.findById(idPrestamo).isPresent()) {
			if (prestamoRepository.findById(idPrestamo).get().getFechaDevolucion() == null) {
				Prestamo p = prestamoRepository.findById(idPrestamo).get();
				p.setFechaDevolucion(fechaAct);
				prestamoRepository.save(p);

				Copia copia = p.getCopia();
				copia.setEstado(EstadoCopia.biblioteca);
				copiaRepository.save(copia);

				// Hay que añadir si tiene que multar o no
				int dias = p.getFechaDevolucion().until(p.getFin()).getDays();
				if (dias < 0) {
					multar(p.getLector().getnSocio(), dias * -2);
				}

				// Comprobar si existian reservas de ese libro.
				List<Reserva> reservas = reservaRepository.findAllByLibroId(copia.getLibro().getId());
				if (reservas.size() > 0) {
					Reserva newReserva= reservas.get(0);
					newReserva.setFechaFinReserva(LocalDate.now().plusDays(DIAS_RESERVA));
					
					reservaRepository.save(newReserva);
					sender.sendSimpleMessage(
							reservas.get(0).getLector().getDireccion(), 
							EMAIL_SUBJECT,
							EMAIL_MESSAGE);
				}
			} else {
				throw new RuntimeException("No se pude devolver, la copia ya se devolvió en: "
						+ prestamoRepository.findById(idPrestamo).get().getFechaDevolucion());
			}
		} else {
			throw new RuntimeException("No existe el prestamo.");
		}
	}

	@Override
	public void prestar(long idLector, long idCopia, LocalDate fechaAct) {
		if (lectorRepository.findById(idLector).isPresent() && copiaRepository.findById(idCopia).isPresent()) {
			List<Prestamo> prestamos = prestamoRepository.findAllByLector_nSocio(idLector);
			int nPrestamos = (int) prestamos.stream().filter((p) -> p.getFechaDevolucion() == null).count();

			List<Multa> multas = multaRepository.findAllByLector_nSocio(idLector);
			int nMultas = (int) multas.stream().filter((m) -> m.getfFin().isAfter(LocalDate.now())).count();
			if (nPrestamos < MAX_PRESTAMOS && nMultas == 0) {
				if (copiaRepository.findById(idCopia).get().getEstado() == EstadoCopia.biblioteca) {

					Copia copia = copiaRepository.findById(idCopia).get();

					List<Reserva> reservas = reservaRepository.findAllByLibroId(copia.getLibro().getId());
					if (reservas.size() == 0) {
						Lector lector = lectorRepository.findById(idLector).get();
						Prestamo prestamo = new Prestamo(lector, copia, fechaAct);
						prestamoRepository.save(prestamo);

						copia.setEstado(EstadoCopia.prestado);
						copiaRepository.save(copia);
					} else {
						throw new RuntimeException("No se puede prestar, la copia esta reservada");
					}
				} else {
					throw new RuntimeException("No se pude prestar, la copia se encuentra prestada.");
				}
			} else {
				throw new RuntimeException("No se puede prestar, el usuario ya tiene 3 prestamos o tiene una multa.");
			}
		} else {
			throw new RuntimeException("Lector o copia no existe.");
		}
	}

	@Override
	public void multar(long idLector, int dias) {
		if (lectorRepository.findById(idLector).isPresent()) {
			Lector lector = lectorRepository.findById(idLector).get();
			Multa multa = new Multa(LocalDate.now(), LocalDate.now().plusDays(dias), lector);
			multaRepository.save(multa);
		} else {
			throw new RuntimeException("No se puede encontrar el lector con id: " + idLector);
		}
	}

	@Override
	public void reservar(long idLector, long idLibro, LocalDate fechaAct) {
		Lector lector = lectorRepository.findById(idLector).get();
		Libro libro = libroRepository.findById(idLibro).get();

		List<Multa> multas = multaRepository.findAllByLector_nSocio(idLector);
		int nMultas = (int) multas.stream().filter((m) -> m.getfFin().isAfter(LocalDate.now())).count();
		if (nMultas == 0) {
			reservaRepository.save(new Reserva(lector, libro, fechaAct));
		} else {
			throw new RuntimeException("No se puede reservar el lector tiene una multa.");
		}
	}
}
