package com.capgemini.biblioteca.service;

import java.time.LocalDate;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Service;

import com.capgemini.biblioteca.model.Libro;
import com.capgemini.biblioteca.model.Reserva;
import com.capgemini.biblioteca.repository.LibroRepository;
import com.capgemini.biblioteca.repository.ReservaRepository;

@Service
public class ReservasServiceImpl implements ReservasService {

	private static final int FIXED_RATE_RESERVAS = 60000;

	private static final int RESERVA_EXPIRATION_TIME = 2;

	private static final String EMAIL_SUBJECT = "RESERVA DISPONIBLE";

	private static final String EMAIL_MESSAGE = "Tiene 48 horas para recoger su reserva";

	@Autowired
	private ReservaRepository reservaRepository;

	@Autowired
	private LibroRepository libroRepository;
	
	@Autowired
	private EmailSenderService sender;

	@Override
	public List<Reserva> getAllReservas() {
		List<Reserva> reservas = reservaRepository.findAll().stream().sorted((x1, x2) -> (int) (x1.getId() - x2.getId()))
				.collect(Collectors.toList());
		for(Reserva reserva : reservas) {
			System.out.println(reserva.toString());
		}
		return reservas;
	}

	@Override
	public void saveReserva(Reserva Reserva) {
		reservaRepository.save(Reserva);
	}

	@Override
	public Reserva getReservaById(long id) {
		Optional<Reserva> optionalReserva = reservaRepository.findById(id);
		Reserva Reserva = null;
		if (optionalReserva.isPresent()) {
			Reserva = optionalReserva.get();
		} else {
			throw new RuntimeException("No se encontró multa " + id);
		}
		return Reserva;
	}

	@Override
	public void deleteReservaById(long id) {
		reservaRepository.deleteById(id);
	}

	@Override
	public List<Reserva> getAllReservasByLectorId(long idLector) {
		return reservaRepository.findAllByLector_nSocio(idLector).stream().sorted((x1, x2) -> (int) (x1.getId() - x2.getId()))
				.collect(Collectors.toList());
	}

	@Override
	public List<Reserva> getAllReservasByLibroId(long idLibro) {
		return reservaRepository.findAllByLibroId(idLibro).stream().sorted((x1, x2) -> (int) (x1.getId() - x2.getId()))
				.collect(Collectors.toList());
	}

	@Scheduled(fixedRate = FIXED_RATE_RESERVAS) // Correr cada minuto
	public void checkReservas() {
		System.out.println("RUTINA RESERVAS");
		List<Libro> libros = libroRepository.findAll();
		for (Libro libro : libros) {
			
			List<Reserva> reservas = (List<Reserva>) reservaRepository.findAllByLibroId(libro.getId());
			
			for (int i = 0; i < reservas.size(); i++) {

				if (reservas.get(i).getFechaFinReserva() != null
						&& reservas.get(i).getFechaFinReserva().isBefore(LocalDate.now())) {
					
					reservaRepository.delete(reservas.get(i));

					if (reservas.size() > 1) {
						Reserva newReserva = reservas.get(i + 1);
						newReserva.setFechaFinReserva(LocalDate.now().plusDays(RESERVA_EXPIRATION_TIME));
						reservaRepository.save(newReserva);
						
						sender.sendSimpleMessage(	
								newReserva.getLector().getDireccion(), 
								EMAIL_SUBJECT,
								EMAIL_MESSAGE);
				
						return;
					}
					
				}
			}
		}
	}
}
