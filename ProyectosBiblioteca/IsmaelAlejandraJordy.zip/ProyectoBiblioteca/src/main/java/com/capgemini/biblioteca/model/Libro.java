package com.capgemini.biblioteca.model;

import java.util.Set;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.Table;

@Entity
@Table(name = "libros")
public class Libro {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long id;

	@Column
	private String titulo;

	@Column
	private String editorial;

	@Column
	private int anyo;

	@Column
	private TipoLibro tipo;

	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "fk_autor")
	private Autor autor;

	@OneToMany(mappedBy = "libro", targetEntity = Copia.class, cascade = CascadeType.ALL)
	private Set<Copia> copias;
	
	@OneToMany(mappedBy = "libro", targetEntity = Reserva.class, cascade = CascadeType.ALL)
	private Set<Reserva> reservas;

	private int cantidad;

	public Libro() {

	}

	public Libro(String titulo, String editorial, int anyo, TipoLibro tipo, Autor autor) {
		super();
		this.titulo = titulo;
		this.editorial = editorial;
		this.anyo = anyo;
		this.tipo = tipo;
		this.autor = autor;
	}

	public int getNCopiasDisponibles() {
		return (int) copias.stream().filter((c) -> c.getEstado()==EstadoCopia.biblioteca).count();
	}

	public int getCantidad() {
		return cantidad;
	}

	public void setCantidad(int cantidad) {
		this.cantidad = cantidad;
	}

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getTitulo() {
		return titulo;
	}

	public void setTitulo(String titulo) {
		this.titulo = titulo;
	}

	public String getEditorial() {
		return editorial;
	}

	public void setEditorial(String editorial) {
		this.editorial = editorial;
	}

	public int getAnyo() {
		return anyo;
	}

	public void setAnyo(int anyo) {
		this.anyo = anyo;
	}

	public TipoLibro getTipo() {
		return tipo;
	}

	public void setTipo(TipoLibro tipo) {
		this.tipo = tipo;
	}

	public Autor getAutor() {
		return autor;
	}

	public void setAutor(Autor autor) {
		this.autor = autor;
	}

	public Set<Copia> getCopias() {
		return copias;
	}

	public void setCopias(Set<Copia> copias) {
		this.copias = copias;
	}



}
