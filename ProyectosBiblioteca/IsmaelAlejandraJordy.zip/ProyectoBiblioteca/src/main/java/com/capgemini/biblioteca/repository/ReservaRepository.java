package com.capgemini.biblioteca.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import com.capgemini.biblioteca.model.Reserva;

public interface ReservaRepository extends JpaRepository<Reserva, Long> {
	List<Reserva> findAllByLibroId(long id);
	List<Reserva> findAllByLector_nSocio(long id);
	void deleteAllByLibroId(Long id);
}
