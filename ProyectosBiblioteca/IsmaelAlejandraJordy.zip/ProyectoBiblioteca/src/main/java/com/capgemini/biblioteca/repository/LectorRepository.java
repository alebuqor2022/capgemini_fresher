package com.capgemini.biblioteca.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.capgemini.biblioteca.model.Lector;

public interface LectorRepository  extends JpaRepository<Lector, Long> {

}
