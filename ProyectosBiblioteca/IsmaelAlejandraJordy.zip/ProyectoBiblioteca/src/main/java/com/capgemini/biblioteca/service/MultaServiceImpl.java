package com.capgemini.biblioteca.service;

import java.time.LocalDate;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collector;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.capgemini.biblioteca.model.Multa;
import com.capgemini.biblioteca.repository.MultaRepository;

@Service
public class MultaServiceImpl implements MultaService {
	@Autowired
	private MultaRepository multaRepository;

	@Override
	public List<Multa> getAllMultas() {
		return multaRepository.findAll();
	}

	@Override
	public void saveMulta(Multa multa) {
		multaRepository.save(multa);
	}

	@Override
	public Multa getMultaById(long id) {
		Optional<Multa> optionalMulta = multaRepository.findById(id);
		Multa multa = null;
		if (optionalMulta.isPresent()) {
			multa = optionalMulta.get();
		} else {
			throw new RuntimeException("No se encontró multa " + id);
		}
		return multa;
	}

	@Override
	public void deleteMultaById(long id) {
		multaRepository.deleteById(id);
	}

	@Override
	public List<Multa> getAllMultaByIdLector(long idLector) {
		
		return multaRepository.findAllByLector_nSocio(idLector);
	}

	@Override
	public List<Multa> getAllMultasVigentesByIdLector(long idLector) {

		return multaRepository.findAllByLector_nSocio(idLector).stream().filter((m) -> m.getfFin().isAfter(LocalDate.now())).collect(Collectors.toList());

	}
}
