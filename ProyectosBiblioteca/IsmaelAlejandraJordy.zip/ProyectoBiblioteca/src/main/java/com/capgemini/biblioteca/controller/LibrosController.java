package com.capgemini.biblioteca.controller;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.capgemini.biblioteca.model.Copia;
import com.capgemini.biblioteca.model.EstadoCopia;
import com.capgemini.biblioteca.model.Lector;
import com.capgemini.biblioteca.model.Libro;
import com.capgemini.biblioteca.service.AutorService;
import com.capgemini.biblioteca.service.CopiaService;
import com.capgemini.biblioteca.service.LectorService;
import com.capgemini.biblioteca.service.LibroService;

@Controller
public class LibrosController {

	@Autowired
	private LibroService ls;

	@Autowired
	private AutorService as;

	@Autowired
	private CopiaService cs;
	
	@Autowired
	private LectorService les;

	@GetMapping("/libros")
	public String viewHome(@RequestParam(name = "tituloLibro") String tituloLibro, Model model) {
		List<Libro> libros;
		if (tituloLibro == "") {
			libros = ls.getAllLibros();
		} else {
			libros = ls.getAllLibrosTitulo(tituloLibro);
		}

		model.addAttribute("libros", libros);

		return "libros";
	}

	@GetMapping("/libros/lector")
	private String viewCopiasLectorLibro(@RequestParam(name = "idLector", required = true) long idLector,
			@RequestParam(name = "tituloLibro") String tituloLibro, Model model) {
		List<Libro> libros = new ArrayList<Libro>();
		Lector lector = les.getLectorById(idLector);
		
		if (tituloLibro == "") {
			libros = ls.getAllLibros();
		} else {
			libros = ls.getAllLibrosTitulo(tituloLibro);
		}

		model.addAttribute("libros", libros);
		model.addAttribute("lector", lector);

		return "libros";
	}

	@GetMapping("/libros/delete/{id}")
	public String deleteLibro(@PathVariable(value = "id", required = true) long id) {
		ls.deleteLibroById(id);
		return "redirect:/libros?tituloLibro=";
	}

	@GetMapping("/libros/add")
	public String viewAddNuevoLibro(Model model) {
		Libro libro = new Libro();
		model.addAttribute("libro", libro);
		model.addAttribute("autores", as.getAllAutores());
		return "nuevo_libro";
	}

	@PostMapping("/libros/save")
	public String saveLibro(@ModelAttribute("libro") Libro libro) {
		ls.saveLibro(libro);
		for (int i = 0; i < libro.getCantidad(); i++) {
			cs.saveCopia(new Copia(EstadoCopia.biblioteca, libro));
		}
		return "redirect:/libros?tituloLibro=";
	}
}
