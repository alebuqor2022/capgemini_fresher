package com.capgemini.biblioteca.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.capgemini.biblioteca.model.Copia;
import com.capgemini.biblioteca.repository.CopiaRepository;

@Service
public class CopiaServiceImpl implements CopiaService {

	@Autowired
	private CopiaRepository copiaRepository;

	@Override
	public List<Copia> getAllCopias() {
		return copiaRepository.findAll();
	}

	@Override
	public void saveCopia(Copia copia) {
		copiaRepository.save(copia);
	}

	@Override
	public Copia getCopiaById(long id) {
		Optional<Copia> optionalCopia = copiaRepository.findById(id);
		Copia copia = null;
		if (optionalCopia.isPresent()) {
			copia = optionalCopia.get();
		} else {
			throw new RuntimeException("La copia no se encuentra nro " + id);
		}
		return copia;
	}

	@Override
	public void deleteCopiaById(long id) {
		copiaRepository.deleteById(id);
	}

	@Override
	public List<Copia> getAllCopiasByLibroId(long idLibro) {
		return copiaRepository.findAllByLibroId(idLibro);
	}

	@Override
	public List<Copia> getAllByTituloContains(String titulo) {
		return copiaRepository.findByLibroTituloContains(titulo);
	}

}
