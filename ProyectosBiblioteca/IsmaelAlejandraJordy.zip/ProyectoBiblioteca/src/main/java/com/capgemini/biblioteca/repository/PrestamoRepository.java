package com.capgemini.biblioteca.repository;

import java.util.List;
import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;

import com.capgemini.biblioteca.model.Prestamo;

public interface PrestamoRepository extends JpaRepository<Prestamo, Long> {
	Optional<List<Prestamo>> findAllByCopiaId(long id);
	List<Prestamo> findAllByLector_nSocio(long id);
	
	void deleteAllByCopiaId(Long id);
}
