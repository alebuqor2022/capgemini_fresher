package com.capgemini.biblioteca.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.capgemini.biblioteca.model.Reserva;
import com.capgemini.biblioteca.service.ReservasService;

@Controller
public class ReservasController {
	@Autowired
	private ReservasService rs;

	@GetMapping("/reservas/lector")
	private String viewreservasLector(@RequestParam(name = "idLector", required = true) long idLector, Model model) {
		List<Reserva> reservas = rs.getAllReservasByLectorId(idLector);
		model.addAttribute("reservas", reservas);

		return "reservas";
	}

	@GetMapping("/reservas/libro")
	private String viewreservasLibro(@RequestParam(name = "idLibro", required = true) long idLibro,Model model) {
		List<Reserva> reservas = rs.getAllReservasByLibroId(idLibro);
		model.addAttribute("reservas", reservas);

		return "reservas";
	}

	@GetMapping("/reservas")
	private String viewreservas(Model model) {
		List<Reserva> reservas = rs.getAllReservas();
		model.addAttribute("reservas", reservas);

		return "reservas";
	}

}
