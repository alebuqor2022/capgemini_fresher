package com.capgemini.biblioteca.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import com.capgemini.biblioteca.model.Copia;

public interface CopiaRepository extends JpaRepository<Copia, Long> {
	List<Copia> findAllByLibroId(long id);
	List<Copia> findByLibroTituloContains(String titulo);
}
